# RamozaClient

Premium ClickGUI (только визуальная часть) для Minecraft **1.21.11**, Fabric, Java 21, Yarn.
GUI-основа плюс модули категории Player: Auto Respawn, Fast Place, Free Cam, Key Pearl, No Jump Delay, No Push, Sprint, XP Macro. Категории без модулей (Render, Pot Cheats) в GUI не рисуются и появятся сами, как только в них зарегистрируют модуль.

## Статус (честно)

| Что | Состояние |
|---|---|
| Слой интерфейса (всё в `gui/`, кроме 3 адаптеров) | компилируется javac без предупреждений, прогнан headless: 36 проверок + фаззинг 6000 событий |
| Адаптеры Minecraft (`McRenderer`, `RamozaScreen`, `RamozaClientMod`) | **не собирались против настоящего Minecraft**, проверены только на заглушках API |
| Модули Player (`module/player/`, `mixin/`) | код проверен javac на заглушках API (синтаксис и типы); **имена методов и полей Minecraft и работа Mixin в игре не проверялись** |
| `gradle build`, запуск в игре | **не проверялись** (в среде разработки не было сети) |

Если CI на GitHub упадёт, пришлите лог: скорее всего это версия в `gradle.properties` или мелкая правка API в одном из трёх адаптеров.

## Как собрать через GitHub

1. Распакуйте архив, получите папку `RamozaClient`.
2. Создайте пустой репозиторий на GitHub и выполните в папке:
   ```
   git init
   git add .
   git commit -m "RamozaClient base"
   git branch -M main
   git remote add origin https://github.com/<вы>/RamozaClient.git
   git push -u origin main
   ```
3. Вкладка **Actions** -> workflow `build` -> артефакт `RamozaClient` (jar). Нужен Fabric API в папке mods.

Локально: `gradle build` (нужен Gradle 9.2+ и JDK 21) или открыть папку в IntelliJ IDEA.
Если Gradle скажет, что версия не найдена, возьмите актуальные для 1.21.11 с https://fabricmc.net/develop/ и поправьте `gradle.properties`.

## Управление

| Клавиша | Действие |
|---|---|
| Right Shift | открыть / закрыть (переназначается в Controls) |
| Esc | закрыть (с анимацией); если идёт назначение клавиши или открыто окно настроек, сначала отменяет их |
| Up / Down | предыдущий / следующий элемент, список сам прокручивается |
| Left / Right | меньше / больше (слайдер, список, переключатель); на модуле: свернуть / развернуть настройки; иначе переход к соседней панели |
| Enter / Space | действие над выбранным элементом |
| Ctrl+F или просто буквы | поиск; Delete очищает |
| ЛКМ / ПКМ по модулю | включить / раскрыть настройки |

**Self Destruct** в этом прототипе только скрывает GUI: он не откроется, пока вы не нажмёте клавишу
**Restore GUI** (по умолчанию `End`, видна в Controls). Ничего не прячется от игры, сервера или системы. Состояние не сохраняется между запусками.

## Структура

```
dev/ramoza/client
  RamozaClientMod        точка входа, клавиши
  core/RamozaCore        общее состояние
  config/                GuiSettings, ConfigManager (config/ramozaclient.properties)
  module/  setting/      ClientModule, Category, настройки модулей
  gui/
    GuiRoot              раскладка, анимация открытия/закрытия, ввод, навигация
    RamozaScreen         адаптер Screen (единственное место с вводом Minecraft)
    theme/               Palette (все цвета), ThemeManager, 6 тем, Dark/Light/Glass
    anim/                Easing, Animation, SmoothFloat (всё на delta time)
    render/              Renderer2D, Gfx (скруглённые углы, тени), McRenderer, Icons
    component/           CategoryPanel, ModuleRow, Toggle, Slider, Dropdown, KeybindButton,
                         ThemeCard, SettingsPanel, Tooltip, SearchBar, BottomBar, ...
```

## Как добавить свой модуль

```java
public final class MyModule extends ClientModule {
    public MyModule() {
        super("My Module", "Что делает", Category.PLAYER);
        add(new BoolSetting("Option", "Подсказка", true));
        add(new NumberSetting("Range", "Подсказка", 3, 1, 6, 0.5));
    }
    @Override protected void onEnable() { /* ... */ }
}
```
Зарегистрируйте в `ModuleManager.registerDefaults()` (заглушек `Example N` больше нет). GUI подхватит модуль, настройки и сохранение сам.

## Модули Player

| Модуль | Что делает | Как реализован |
|---|---|---|
| Auto Respawn | сам нажимает «Возродиться» на экране смерти; настройка `Delay` (тики); в хардкоре ничего не делает | `DeathScreen` + `requestRespawn()` |
| No Jump Delay | убирает паузу между прыжками при зажатом пробеле | Mixin-аксессор `LivingEntity.jumpingCooldown` |
| No Push | игрока не толкают сущности и жидкости (настройки `Entities`, `Liquids`) | Mixin `Entity.pushAwayFrom`, `PlayerEntity.isPushedByFluids` |
| Sprint | спринт автоматически при зажатой клавише вперёд | нажимает клавишу спринта, остальные условия проверяет сама игра |
| Fast Place | быстрая установка при зажатой ПКМ; `Delay (ms)` 0-200, `Random Delay`, `Blocks Only` | аксессор `MinecraftClient.itemUseCooldown` |
| Free Cam | камера отделяется от игрока, летает WASD/Space/Shift; `Speed` | `CameraMixin` (позиция камеры), `Entity.changeLookDirection` (мышь), клавиши движения сбрасываются |
| Key Pearl | по клавише: слот Pearl, бросок, слот Totem; `Pearl Slot`, `Totem Slot` (1-9), `Delay (ms)`, `Random Delay` | опрос GLFW, `interactItem`; без жемчуга в слоте ничего не делает |
| XP Macro | спамит бутылки опыта из любой руки, хотбара или инвентаря; `Activation` (Always / Hold Key), `Key`, `Search Inventory`, `Delay (ms)`, `Random Delay` | `interactItem`, для инвентаря `clickSlot(SWAP)` туда и обратно |

| Auto Inventory Totem | при открытии инвентаря (E) один раз при открытии переносит тотем из инвентаря в `Totem Slot` (1-9), без задержек | `clickSlot(SWAP)` на экране инвентаря |
| Hover Totem | наведение на тотем в инвентаре без клика переносит его; `OffHand Totem` (сначала в левую руку, потом в `Totem Slot`), `Totem Slot`, `Delay (ms)`, `Random Delay` | `HandledScreenAccessor.focusedSlot`, `clickSlot(SWAP)` (кнопка 40 = левая рука) |
| Totem Offhand | нет тотема в левой руке: тотем в `Totem Slot`, выбор слота, F, возврат слота; `Open Inventory`, `Delay (ms)`, `Random Delay` | `clickSlot(SWAP)` + пакет `SWAP_ITEM_WITH_OFFHAND`; выбор слота и F в разных тиках |
| Auto Double Hand | при ударе, потере здоровья или подбросе вверх (взрыв, якорь, заряд ветра) выбирает `Totem Slot`, если там тотем; `Return Slot`, `Return Delay (ms)` (возврат прежнего слота после последнего удара), `Delay (ms)`, `Random Delay` | `hurtTime`, здоровье, скорость по Y > 0.6 |
| Auto Mace | в падении бьёт цель под прицелом булавой: слот булавы, удар, возврат слота; `Min Fall Distance` | `attackEntity` + `swingHand`, один удар за падение |
| Mace Swap | при вашем клике по сущности в падении переключает слот на булаву до пакета атаки и возвращает после задержки | `MinecraftClientMixin` на `doAttack` |
| Stun Slam | клик по цели со щитом в падении: топор, пауза, булава, пауза, возврат слота | тот же хук; нужны топор и булава в хотбаре |
| Lunge Swap | по клавише: слот копья, обычный левый клик (рывок Lunge), после паузы слот `Hand Slot` | `MinecraftClientAccessor.doAttack` (invoker) |
| Pearl Catch | по клавише: пёрл, пауза, заряд ветра (по умолчанию взгляд вниз, питч потом возвращается), пауза, возврат слота | `Pearl Slot`, `WindCharge Slot` |
| Elytra Swap | нагрудник ↔ элитры без инвентаря тремя кликами `clickSlot`; `Mode`: Key или Auto (элитры при падении, нагрудник при приземлении) | слот брони 6 |

У всех шести: `Activate Key`, `Delay (ms)`, `Random Delay`. Для Auto Mace, Mace Swap и Stun Slam Activate Key работает как «взведено, пока зажата» (не назначена = всегда взведено). Для Lunge Swap, Pearl Catch и Elytra Swap это нажатие-триггер. Шаги идут через `MacroRunner` (по тикам, без `Thread.sleep`), и после каждого шага задержка выбирается заново.

**Random Delay** (везде, где есть задержка, включая Auto Respawn): на каждом новом действии задержка заново выбирается как `Delay ± Random Delay` (например 25 ± 2 = 23..27 мс), не меньше 0. Модули тикают 20 раз в секунду, поэтому задержка проверяется раз в тик (~50 мс): реальное ожидание округляется вверх до тика. Delay у Auto Respawn по-прежнему в тиках, Random Delay у него в мс.

Модули в каждой категории выводятся по алфавиту (без учёта регистра, числа по значению), порядок задаётся в `ModuleManager.in()`.
Тик модулей: `ModuleManager.tick()` из `START_CLIENT_TICK`.

## Последние изменения (не собирались против настоящего Minecraft)

- **Auto Crystal**: настройка `Return` (вкл по умолчанию). Выключена: слот после установки не возвращается.
- **Подсказки** над хотбаром («негде разместить» и т.п.) удалены из Auto Crystal, Anchor Macro, Anchor Pearl, Double Anchor (`PlayerActions.hint` убран). Отладочное сообщение Stun Slam (`Debug`, выкл по умолчанию) не трогалось.
- **Anchor Macro, Anchor Pearl, Double Anchor**: настройка `Mode` = `Silent` (как раньше) или `Legit`. В Legit каждый клик идёт туда, куда вы реально смотрите (луч из глаз пересчитывается на каждом шаге), а если отвернулись, макрос останавливается и возвращает слот.
- **Double Anchor**: новый `Second Spot = Beside` (по умолчанию). Причина «один взрыв на камне»: первый взрыв разрушает камень под якорем, второму некуда встать. Якорь взрывом не разрушается, поэтому второй якорь ставится сразу после первого, до зарядки и взрыва, рядом на любой блок-опору, затем оба заряжаются и взрываются. В Legit второй якорь ставится на блок, на который вы смотрите после первого взрыва (в пределах 3 блоков от первого).
- **Watermark** (Render -> Watermark): два ряда пилюль, значок логотипа `R` шрифтом Blacksword. Переключатели Username, FPS, Logo, Ping, Time, Coords, TPS, BPS, Server; `Corner Rounding`, `Background Opacity`. Перетаскивается левой кнопкой мыши, пока открыт ClickGUI; позиция хранится в конфиге (`hud.watermark.x/y`).
  - TPS это оценка по интервалу между пакетами времени сервера (раз в 20 тиков); до двух пакетов показывает `--`.
  - Под сомнением: `HudRenderCallback` (в новых Fabric API помечен устаревшим, замена `HudElementRegistry`), имя метода `ClientPlayNetworkHandler.onWorldTimeUpdate` (у миксина `require = 0`, при несовпадении просто не будет TPS), `Entity.raycast(double, float, boolean)`, `PlayerListEntry.getLatency`.

## Известные ограничения

- **Новые модули Player не собирались против настоящего Minecraft**: проверены javac на заглушках API. Под сомнением имена `PlayerInventory.getSelectedSlot/setSelectedSlot`, `MinecraftClient.itemUseCooldown`, `Entity.changeLookDirection`, `Camera.update / isThirdPerson / setPos / setRotation`. Если сборка или запуск упадёт, пришлите лог.
- **Макросы Mace/Spear/Pearl/Elytra** тоже не собирались против настоящего Minecraft. Под сомнением `MinecraftClient.doAttack` (возвращает boolean), `Entity.fallDistance`, `PlayerInventory.setSelectedSlot`. Что именно делает Lunge на копье в 1.21.11, мод не знает: он просто делает обычный левый клик, остальное решает игра.
- **Модули Totem** (Auto Inventory Totem, Hover Totem, Totem Offhand, Auto Double Hand) не собирались: под сомнением `HandledScreen.focusedSlot`, `LivingEntity.hurtTime`, `LivingEntity.isGliding`, конструктор `PlayerActionC2SPacket(Action, BlockPos, Direction)`. Hover Totem работает только в обычном инвентаре игрока.
- **Free Cam** не блокирует клики: атака и использование предметов идут из позиции игрока, а не камеры.
- **XP Macro** не наводится: смотрите туда, куда должны упасть бутылки.
- **Key Pearl** не проверяет, что в Totem Slot лежит тотем: просто переключается на этот слот.

- **No Push** не отменяет выталкивание из блоков и скорость, присланную сервером (отдача, velocity-пакеты).

- **Версия.** В техзадании была 1.21.1, проект собран под **1.21.11**. С 1.21.6 и 1.21.9 изменились API рендера и ввода, поэтому под 1.21.1 понадобится переписать только `McRenderer`, `RamozaScreen` и регистрацию клавиши.
- **Blur** это штатный blur меню Minecraft: он включается мгновенно и не анимируется (его сила задаётся в настройках видео). Liquid Glass без blur остаётся стеклом за счёт полупрозрачных слоёв.
- **Шрифт** стандартный шрифт Minecraft. Кастомный TTF потребует ресурс-пака со шрифтом.
- Скругления сглаживаются построчно: чётче всего при `Scale = 1.0`. В очень маленьком окне GUI автоматически уменьшается, и края становятся грубее.
- Около 5000 прямоугольников на кадр (в основном скругления). Если упадёт FPS, уменьшите `Corner Rounding` или отключите Blur.
- Панели нельзя перетаскивать; нет вставки из буфера в поиск.
- Превью в `docs/preview/` получены программным рендером: шрифт и blur в игре будут отличаться.
